var R=require("../../chunks/[turbopack]_runtime.js")("server/app/twitter-image.png/route.js")
R.c("server/chunks/[root-of-the-server]__807ba5e1._.js")
R.c("server/chunks/7c561_next_710d28d6._.js")
R.c("server/chunks/[root-of-the-server]__b4f2f322._.js")
R.c("server/chunks/7c561_next_dist_esm_build_templates_app-route_fa57584e.js")
R.c("server/chunks/_next-internal_server_app_twitter-image_png_route_actions_9bd4588b.js")
R.m(60790)
module.exports=R.m(60790).exports
