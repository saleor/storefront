var R=require("../../chunks/[turbopack]_runtime.js")("server/app/icon.png/route.js")
R.c("server/chunks/[root-of-the-server]__807ba5e1._.js")
R.c("server/chunks/7c561_next_dist_esm_build_templates_app-route_4e6c5f7f.js")
R.c("server/chunks/7c561_next_710d28d6._.js")
R.c("server/chunks/[root-of-the-server]__b4f2f322._.js")
R.c("server/chunks/_next-internal_server_app_icon_png_route_actions_fa3562e2.js")
R.m(86530)
module.exports=R.m(86530).exports
