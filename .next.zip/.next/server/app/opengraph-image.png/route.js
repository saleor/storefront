var R=require("../../chunks/[turbopack]_runtime.js")("server/app/opengraph-image.png/route.js")
R.c("server/chunks/[root-of-the-server]__807ba5e1._.js")
R.c("server/chunks/7c561_next_710d28d6._.js")
R.c("server/chunks/[root-of-the-server]__b4f2f322._.js")
R.c("server/chunks/7c561_next_dist_esm_build_templates_app-route_74151798.js")
R.c("server/chunks/_next-internal_server_app_opengraph-image_png_route_actions_d62f126e.js")
R.m(60457)
module.exports=R.m(60457).exports
