var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/prefetch-images/route.js")
R.c("server/chunks/[root-of-the-server]__d675f1df._.js")
R.c("server/chunks/7c561_next_b7b26166._.js")
R.c("server/chunks/[root-of-the-server]__b4f2f322._.js")
R.c("server/chunks/_93eda5bd._.js")
R.c("server/chunks/7c561_next_710d28d6._.js")
R.c("server/chunks/_next-internal_server_app_api_prefetch-images_route_actions_caa1cf47.js")
R.m(8350)
module.exports=R.m(8350).exports
