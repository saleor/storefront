var R=require("../../chunks/[turbopack]_runtime.js")("server/app/icon.svg/route.js")
R.c("server/chunks/[root-of-the-server]__4efcb6f0._.js")
R.c("server/chunks/[root-of-the-server]__b4f2f322._.js")
R.c("server/chunks/7c561_next_710d28d6._.js")
R.c("server/chunks/_next-internal_server_app_icon_svg_route_actions_d76bbd00.js")
R.m(86530)
module.exports=R.m(86530).exports
