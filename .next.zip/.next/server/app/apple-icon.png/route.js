var R=require("../../chunks/[turbopack]_runtime.js")("server/app/apple-icon.png/route.js")
R.c("server/chunks/[root-of-the-server]__9d6f6520._.js")
R.c("server/chunks/[root-of-the-server]__b4f2f322._.js")
R.c("server/chunks/7c561_next_710d28d6._.js")
R.c("server/chunks/_next-internal_server_app_apple-icon_png_route_actions_40001896.js")
R.m(61948)
module.exports=R.m(61948).exports
