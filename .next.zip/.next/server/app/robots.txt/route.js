var R=require("../../chunks/[turbopack]_runtime.js")("server/app/robots.txt/route.js")
R.c("server/chunks/[root-of-the-server]__3d6c2c03._.js")
R.c("server/chunks/[root-of-the-server]__b4f2f322._.js")
R.c("server/chunks/7c561_next_710d28d6._.js")
R.c("server/chunks/_next-internal_server_app_robots_txt_route_actions_9118e90f.js")
R.m(25622)
module.exports=R.m(25622).exports
