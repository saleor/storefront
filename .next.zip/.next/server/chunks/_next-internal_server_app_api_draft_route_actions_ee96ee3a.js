module.exports=[40986,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_draft_route_actions_ee96ee3a.js.map