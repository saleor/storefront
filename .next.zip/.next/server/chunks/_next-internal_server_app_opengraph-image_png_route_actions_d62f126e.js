module.exports=[30934,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_opengraph-image_png_route_actions_d62f126e.js.map