module.exports=[65145,a=>{"use strict";var b,c=function(a,b){return(c=Object.setPrototypeOf||({__proto__:[]})instanceof Array&&function(a,b){a.__proto__=b}||function(a,b){for(var c in b)Object.prototype.hasOwnProperty.call(b,c)&&(a[c]=b[c])})(a,b)};"function"==typeof SuppressedError&&SuppressedError;var d="Invariant Violation",e=Object.setPrototypeOf,f=void 0===e?function(a,b){return a.__proto__=b,a}:e,g=function(a){if("function"!=typeof a&&null!==a)throw TypeError("Class extends value "+String(a)+" is not a constructor or null");function b(){this.constructor=e}function e(b){void 0===b&&(b=d);var c=a.call(this,"number"==typeof b?d+": "+b+" (see https://github.com/apollographql/invariant-packages)":b)||this;return c.framesToPop=1,c.name=d,f(c,e.prototype),c}return c(e,a),e.prototype=null===a?Object.create(a):(b.prototype=a.prototype,new b),e}(Error);function h(a,b){if(!a)throw new g(b)}var i=["debug","log","warn","error","silent"],j=i.indexOf("log");function k(a){return function(){if(i.indexOf(a)>=j)return(console[a]||console.log).apply(console,arguments)}}(b=h||(h={})).debug=k("debug"),b.log=k("log"),b.warn=k("warn"),b.error=k("error"),a.s(["invariant",()=>h],65145)},41811,(a,b,c)=>{"use strict";c.parse=function(a,b){if("string"!=typeof a)throw TypeError("argument str must be a string");for(var c={},d=(b||{}).decode||f,e=0;e<a.length;){var g=a.indexOf("=",e);if(-1===g)break;var h=a.indexOf(";",e);if(-1===h)h=a.length;else if(h<g){e=a.lastIndexOf(";",g-1)+1;continue}var i=a.slice(e,g).trim();if(void 0===c[i]){var j=a.slice(g+1,h).trim();34===j.charCodeAt(0)&&(j=j.slice(1,-1)),c[i]=function(a,b){try{return b(a)}catch(b){return a}}(j,d)}e=h+1}return c},c.serialize=function(a,b,c){var f=c||{},h=f.encode||g;if("function"!=typeof h)throw TypeError("option encode is invalid");if(!e.test(a))throw TypeError("argument name is invalid");var i=h(b);if(i&&!e.test(i))throw TypeError("argument val is invalid");var j=a+"="+i;if(null!=f.maxAge){var k=f.maxAge-0;if(isNaN(k)||!isFinite(k))throw TypeError("option maxAge is invalid");j+="; Max-Age="+Math.floor(k)}if(f.domain){if(!e.test(f.domain))throw TypeError("option domain is invalid");j+="; Domain="+f.domain}if(f.path){if(!e.test(f.path))throw TypeError("option path is invalid");j+="; Path="+f.path}if(f.expires){var l,m=f.expires;if(l=m,"[object Date]"!==d.call(l)&&!(l instanceof Date)||isNaN(m.valueOf()))throw TypeError("option expires is invalid");j+="; Expires="+m.toUTCString()}if(f.httpOnly&&(j+="; HttpOnly"),f.secure&&(j+="; Secure"),f.partitioned&&(j+="; Partitioned"),f.priority)switch("string"==typeof f.priority?f.priority.toLowerCase():f.priority){case"low":j+="; Priority=Low";break;case"medium":j+="; Priority=Medium";break;case"high":j+="; Priority=High";break;default:throw TypeError("option priority is invalid")}if(f.sameSite)switch("string"==typeof f.sameSite?f.sameSite.toLowerCase():f.sameSite){case!0:case"strict":j+="; SameSite=Strict";break;case"lax":j+="; SameSite=Lax";break;case"none":j+="; SameSite=None";break;default:throw TypeError("option sameSite is invalid")}return j};var d=Object.prototype.toString,e=/^[\u0009\u0020-\u007e\u0080-\u00ff]+$/;function f(a){return -1!==a.indexOf("%")?decodeURIComponent(a):a}function g(a){return encodeURIComponent(a)}},69421,a=>{"use strict";var b=a=>[a,"saleor_auth_access_token"].filter(Boolean).join("+"),c=class{constructor(a,b){this.storage=a,this.prefix=b}getAccessToken=()=>{let a=b(this.prefix);return this.storage.getItem(a)};setAccessToken=a=>{let c=b(this.prefix);return this.storage.setItem(c,a)};clearAuthStorage=()=>{let a=b(this.prefix);return this.storage.removeItem(a)}},d=a=>[a,"saleor_auth_module_auth_state"].filter(Boolean).join("+"),e=a=>[a,"saleor_auth_module_refresh_token"].filter(Boolean).join("+"),f=class{constructor(a,b){this.storage=a,this.prefix=b}handleStorageChange=a=>{let{oldValue:b,newValue:c,type:e,key:f}=a;b!==c&&"storage"===e&&f===d(this.prefix)&&this.sendAuthStateEvent(c)};cleanup=()=>{};sendAuthStateEvent=a=>{};getAuthState=()=>this.storage.getItem(d(this.prefix))||"signedOut";setAuthState=a=>{this.storage.setItem(d(this.prefix),a),this.sendAuthStateEvent(a)};getRefreshToken=()=>this.storage.getItem(e(this.prefix))||null;setRefreshToken=a=>{this.storage.setItem(e(this.prefix),a)};clearAuthStorage=()=>{this.setAuthState("signedOut"),this.storage.removeItem(e(this.prefix))}},g=a=>{let b=a.split(".");return JSON.parse(Buffer.from(b[1]||"","base64").toString())},h=(a,b)=>(1e3*g(a).exp||0)-b<=Date.now(),i=(a,b,c)=>({...c,method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({query:a,variables:b})}),j=class extends Error{constructor(a){super(a)}},k=class extends String{constructor(a,b){super(a),this.value=a,this.__meta__=b}__apiType;toString(){return this.value}},l=`
  fragment AccountErrorFragment on AccountError {
    code
    field
    message
  }
`,m=new k(`
  ${l}
  mutation refreshToken($refreshToken: String!) {
    tokenRefresh(refreshToken: $refreshToken) {
      token
      errors {
        ...AccountErrorFragment
      }
    }
  }
`),n=new k(`
  mutation tokenCreate($email: String!, $password: String!) {
    tokenCreate(email: $email, password: $password) {
      token
      refreshToken
      errors {
        message
        field
        code
      }
    }
  }
`),o=new k(`
  mutation passwordReset($email: String!, $password: String!, $token: String!) {
    setPassword(email: $email, password: $password, token: $token) {
      token
      refreshToken
      errors {
        message
        field
        code
      }
    }
  }
`);new k(`
  mutation externalAuthenticationUrl($pluginId: String!, $input: JSONString!) {
    externalAuthenticationUrl(pluginId: $pluginId, input: $input) {
      authenticationData
      errors {
        code
        field
        message
      }
    }
  }
`),new k(`
  mutation AuthObtainAccessToken($pluginId: String!, $input: JSONString!) {
    externalObtainAccessTokens(pluginId: $pluginId, input: $input) {
      token
      refreshToken
      user {
        id
        email
      }
      errors {
        field
        code
        message
      }
    }
  }
`);var p=a.i(41811),q=class{tokenGracePeriod=2e3;tokenRefreshPromise=null;onAuthRefresh;saleorApiUrl;refreshTokenStorage;acessTokenStorage;defaultRequestInit;constructor({saleorApiUrl:a,refreshTokenStorage:b,accessTokenStorage:d,onAuthRefresh:e,tokenGracePeriod:g,defaultRequestInit:h}){this.defaultRequestInit=h,g&&(this.tokenGracePeriod=g),this.onAuthRefresh=e,this.saleorApiUrl=a;const i=b??void 0;this.refreshTokenStorage=i?new f(i,a):null;const j=d??function(){let a=null;return{getItem:()=>a,removeItem:()=>a=null,setItem:(b,c)=>a=c}}();this.acessTokenStorage=new c(j,a)}cleanup=()=>{this.refreshTokenStorage?.cleanup()};runAuthorizedRequest=(a,b,c)=>{let d=this.acessTokenStorage.getAccessToken();if(!d)return fetch(a,b);let e=b?.headers||{},f=g(d).iss,h=("string"==typeof a?a:"url"in a?a.url:a.href)===f,i=h||c?.allowPassingTokenToThirdPartyDomains;return h||(i?console.warn("Token's `iss` and request URL do not match but `allowPassingTokenToThirdPartyDomains` was specified."):console.warn("Token's `iss` and request URL do not match. Not adding `Authorization` header to the request.")),fetch(a,{...b,headers:i?{...e,Authorization:`Bearer ${d}`}:e})};handleRequestWithTokenRefresh=async(a,b,c)=>{let d=this.refreshTokenStorage?.getRefreshToken();if(!d)throw new j("Invariant Violation: Missing refresh token in token refresh handler");let e=this.acessTokenStorage.getAccessToken();if(e&&!h(e,this.tokenGracePeriod))return this.fetchWithAuth(a,b,c);if(this.onAuthRefresh?.(!0),this.tokenRefreshPromise){let d=await this.tokenRefreshPromise,{errors:e,data:{tokenRefresh:{errors:f,token:g}}}=await d.clone().json();return(this.onAuthRefresh?.(!1),f?.length||e?.length||!g)?(this.tokenRefreshPromise=null,this.refreshTokenStorage?.clearAuthStorage(),fetch(a,b)):(this.refreshTokenStorage?.setAuthState("signedIn"),this.acessTokenStorage.setAccessToken(g),this.tokenRefreshPromise=null,this.runAuthorizedRequest(a,b,c))}return this.tokenRefreshPromise=fetch(this.saleorApiUrl,i(m,{refreshToken:d},{...this.defaultRequestInit,...b})),this.fetchWithAuth(a,b,c)};handleSignIn=async a=>{let b=await a.json(),c="tokenCreate"in b.data?b.data.tokenCreate:b.data.setPassword;if(!c)return b;let{errors:d,token:e,refreshToken:f}=c;return!e||d.length?this.refreshTokenStorage?.setAuthState("signedOut"):(e&&this.acessTokenStorage.setAccessToken(e),f&&this.refreshTokenStorage?.setRefreshToken(f),this.refreshTokenStorage?.setAuthState("signedIn")),b};fetchWithAuth=async(a,b,c)=>{let d=this.refreshTokenStorage?.getRefreshToken();if(!this.acessTokenStorage.getAccessToken()&&"undefined"!=typeof document){let a=p.default.parse(document.cookie).token??null;a&&this.acessTokenStorage.setAccessToken(a),document.cookie=p.default.serialize("token","",{expires:new Date(0),path:"/"})}let e=this.acessTokenStorage.getAccessToken();return e&&!h(e,this.tokenGracePeriod)?this.runAuthorizedRequest(a,b,c):d?this.handleRequestWithTokenRefresh(a,b,c):fetch(a,b)};resetPassword=async(a,b)=>{let c=await fetch(this.saleorApiUrl,i(o,a,{...this.defaultRequestInit,...b}));return this.handleSignIn(c)};signIn=async(a,b)=>{let c=await fetch(this.saleorApiUrl,i(n,a,{...this.defaultRequestInit,...b}));return this.handleSignIn(c)};signOut=()=>{this.acessTokenStorage.clearAuthStorage(),this.refreshTokenStorage?.clearAuthStorage(),"undefined"!=typeof document&&(document.cookie=p.default.serialize("token","",{expires:new Date(0),path:"/"}))}},r=a.i(10724),s=async(a={})=>{let b=(0,r.cookies)();if(!(b instanceof Promise))throw Error("This function should only be used with async cookies!");return((a={},b)=>{let c=a.secure??!0,d=new Map;return{getItem:a=>d.get(a)??b.get(a)?.value??null,removeItem(a){d.delete(a),b.delete(a)},setItem(a,e){try{d.set(a,e);let f=t(e);b.set(a,e,{httpOnly:!0,sameSite:"lax",secure:c,expires:f})}catch{}}}})(a,await b)},t=a=>{try{let b=JSON.parse(atob(a.split(".")[1]??"")).exp,c=Date.now()/1e3;if(b&&"number"==typeof b&&b>c)return new Date(1e3*b)}catch{}},u=a.i(65145);let v="https://saleor-api.sonicdrivestudio.com/graphql/";(0,u.invariant)(v,"Missing NEXT_PUBLIC_SALEOR_API_URL env variable");let w=async()=>{let a=await s();return new q({saleorApiUrl:v,refreshTokenStorage:a,accessTokenStorage:a})};a.s(["DEFAULT_CHANNEL",0,"default-channel","ProductsPerPage",0,12,"getServerAuthClient",0,w],69421)}];

//# sourceMappingURL=_8fad004e._.js.map