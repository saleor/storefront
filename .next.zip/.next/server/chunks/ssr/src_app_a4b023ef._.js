module.exports=[13682,a=>{a.v("/_next/static/media/opengraph-image.47aadea7.png")},10496,a=>{"use strict";let b={src:a.i(13682).default,width:1200,height:630};a.s(["default",0,b])}];

//# sourceMappingURL=src_app_a4b023ef._.js.map