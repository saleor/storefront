module.exports=[7524,a=>{a.v("/_next/static/media/icon.73a2e3ed.svg")},39375,a=>{"use strict";let b={src:a.i(7524).default,width:128,height:128};a.s(["default",0,b])}];

//# sourceMappingURL=src_app_0db9afea._.js.map