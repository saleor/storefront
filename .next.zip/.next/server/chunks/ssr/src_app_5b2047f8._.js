module.exports=[10585,a=>{a.v("/_next/static/media/favicon.9e9e7569.ico")},68611,a=>{"use strict";let b={src:a.i(10585).default,width:48,height:48};a.s(["default",0,b])}];

//# sourceMappingURL=src_app_5b2047f8._.js.map