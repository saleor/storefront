module.exports=[89221,a=>{"use strict";var b=a.i(3071);let c={title:"Confirm Account",description:`Confirm your ${b.SITE_CONFIG.name} account to complete registration and access your purchases.`};function d({children:a}){return a}a.s(["default",()=>d,"metadata",0,c])}];

//# sourceMappingURL=src_app_%28main%29_confirm-account_layout_tsx_8af7b01d._.js.map