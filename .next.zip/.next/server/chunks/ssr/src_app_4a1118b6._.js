module.exports=[37769,a=>{a.v("/_next/static/media/apple-icon.93d5180a.png")},9361,a=>{"use strict";let b={src:a.i(37769).default,width:180,height:180};a.s(["default",0,b])}];

//# sourceMappingURL=src_app_4a1118b6._.js.map