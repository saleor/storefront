module.exports=[23813,a=>{a.v("/_next/static/media/twitter-image.47aadea7.png")},56873,a=>{"use strict";let b={src:a.i(23813).default,width:1200,height:630};a.s(["default",0,b])}];

//# sourceMappingURL=src_app_bd834e3b._.js.map