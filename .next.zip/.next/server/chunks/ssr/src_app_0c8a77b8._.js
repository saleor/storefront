module.exports=[25333,a=>{a.v("/_next/static/media/icon.a72b5a3e.png")},21646,a=>{"use strict";let b={src:a.i(25333).default,width:512,height:512};a.s(["default",0,b])}];

//# sourceMappingURL=src_app_0c8a77b8._.js.map