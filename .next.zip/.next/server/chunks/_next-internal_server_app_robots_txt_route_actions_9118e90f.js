module.exports=[38285,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_robots_txt_route_actions_9118e90f.js.map