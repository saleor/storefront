module.exports=[60722,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_icon_svg_route_actions_d76bbd00.js.map