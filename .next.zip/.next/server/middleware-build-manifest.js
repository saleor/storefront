globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/c3c49269e78eda28.js",
    "static/chunks/acd39295bd6c05cf.js",
    "static/chunks/2cd85d3620ef3dda.js",
    "static/chunks/f7bea5a15ab94942.js",
    "static/chunks/01af958c3328c376.js",
    "static/chunks/turbopack-c6beb9ef529e355b.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];