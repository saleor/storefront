module.exports = [
"[project]/.next-internal/server/app/api/prefetch-images/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
}),
];

//# sourceMappingURL=_next-internal_server_app_api_prefetch-images_route_actions_caa1cf47.js.map