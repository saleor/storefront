module.exports = [
"[project]/src/app/favicon.ico.mjs { IMAGE => \"[project]/src/app/favicon.ico (static in ecmascript, tag client)\" } [app-rsc] (structured image object, ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/favicon.ico.mjs { IMAGE => \"[project]/src/app/favicon.ico (static in ecmascript, tag client)\" } [app-rsc] (structured image object, ecmascript)"));
}),
"[project]/src/app/icon.png.mjs { IMAGE => \"[project]/src/app/icon.png (static in ecmascript, tag client)\" } [app-rsc] (structured image object, ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/icon.png.mjs { IMAGE => \"[project]/src/app/icon.png (static in ecmascript, tag client)\" } [app-rsc] (structured image object, ecmascript)"));
}),
"[project]/src/app/icon.svg.mjs { IMAGE => \"[project]/src/app/icon.svg (static in ecmascript, tag client)\" } [app-rsc] (structured image object, ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/icon.svg.mjs { IMAGE => \"[project]/src/app/icon.svg (static in ecmascript, tag client)\" } [app-rsc] (structured image object, ecmascript)"));
}),
"[project]/src/app/apple-icon.png.mjs { IMAGE => \"[project]/src/app/apple-icon.png (static in ecmascript, tag client)\" } [app-rsc] (structured image object, ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/apple-icon.png.mjs { IMAGE => \"[project]/src/app/apple-icon.png (static in ecmascript, tag client)\" } [app-rsc] (structured image object, ecmascript)"));
}),
"[project]/src/app/twitter-image.png.mjs { IMAGE => \"[project]/src/app/twitter-image.png (static in ecmascript, tag client)\" } [app-rsc] (structured image object, ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/twitter-image.png.mjs { IMAGE => \"[project]/src/app/twitter-image.png (static in ecmascript, tag client)\" } [app-rsc] (structured image object, ecmascript)"));
}),
"[project]/src/app/opengraph-image.png.mjs { IMAGE => \"[project]/src/app/opengraph-image.png (static in ecmascript, tag client)\" } [app-rsc] (structured image object, ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/opengraph-image.png.mjs { IMAGE => \"[project]/src/app/opengraph-image.png (static in ecmascript, tag client)\" } [app-rsc] (structured image object, ecmascript)"));
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[project]/src/app/layout.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/layout.tsx [app-rsc] (ecmascript)"));
}),
"[project]/src/app/error.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/error.tsx [app-rsc] (ecmascript)"));
}),
"[project]/src/app/not-found.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/not-found.tsx [app-rsc] (ecmascript)"));
}),
"[project]/src/app/(main)/layout.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/(main)/layout.tsx [app-rsc] (ecmascript)"));
}),
"[project]/src/app/(main)/loading.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/(main)/loading.tsx [app-rsc] (ecmascript)"));
}),
"[project]/src/lib/editorjs/parser.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Enhanced Editor.js parser with support for all block types
 * Extends editorjs-html with custom renderers for advanced blocks
 */ __turbopack_context__.s([
    "createEditorJsParser",
    ()=>createEditorJsParser,
    "parseEditorJsToHTML",
    ()=>parseEditorJsToHTML
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$editorjs$2d$html$40$3$2e$4$2e$3$2f$node_modules$2f$editorjs$2d$html$2f$build$2f$edjsHTML$2e$node$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/editorjs-html@3.4.3/node_modules/editorjs-html/build/edjsHTML.node.js [app-rsc] (ecmascript)");
;
// Custom parser configurations for new block types
const customParsers = {
    table: (block)=>{
        const content = block.data?.content || [];
        if (!content.length) return "";
        const withHeadings = block.data?.withHeadings || false;
        let html = '<table class="editorjs-table">';
        content.forEach((row, index)=>{
            html += "<tr>";
            const tag = withHeadings && index === 0 ? "th" : "td";
            row.forEach((cell)=>{
                html += `<${tag}>${cell}</${tag}>`;
            });
            html += "</tr>";
        });
        html += "</table>";
        return html;
    },
    checklist: (block)=>{
        const items = block.data?.items || [];
        if (!items.length) return "";
        let html = '<ul class="editorjs-checklist">';
        items.forEach((item)=>{
            const checked = item.checked ? "checked" : "";
            html += `<li class="editorjs-checklist-item ${checked}">`;
            html += `<input type="checkbox" ${checked} disabled />`;
            html += `<span>${item.text}</span>`;
            html += "</li>";
        });
        html += "</ul>";
        return html;
    },
    code: (block)=>{
        const code = block.data?.code || "";
        // Escape HTML to prevent XSS
        const escaped = code.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
        return `<pre class="editorjs-code"><code>${escaped}</code></pre>`;
    },
    delimiter: ()=>{
        return '<div class="editorjs-delimiter">* * *</div>';
    },
    warning: (block)=>{
        const title = block.data?.title || "";
        const message = block.data?.message || "";
        return `
			<div class="editorjs-warning">
				${title ? `<div class="editorjs-warning-title">${title}</div>` : ""}
				${message ? `<div class="editorjs-warning-message">${message}</div>` : ""}
			</div>
		`;
    },
    attaches: (block)=>{
        const file = block.data?.file || {};
        const title = block.data?.title || file.name || "Download";
        if (!file.url) return "";
        const size = file.size ? ` (${formatFileSize(file.size)})` : "";
        return `
			<div class="editorjs-attaches">
				<a href="${file.url}" target="_blank" rel="noopener noreferrer" class="editorjs-attaches-link">
					<svg class="editorjs-attaches-icon" width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
						<path d="M10 0C4.48 0 0 4.48 0 10C0 15.52 4.48 20 10 20C15.52 20 20 15.52 20 10C20 4.48 15.52 0 10 0ZM11 15H9V9H11V15ZM11 7H9V5H11V7Z" fill="currentColor"/>
					</svg>
					<span class="editorjs-attaches-title">${title}</span>
					${size ? `<span class="editorjs-attaches-size">${size}</span>` : ""}
				</a>
			</div>
		`;
    },
    raw: (block)=>{
        // Raw HTML - already sanitized by backend
        return block.data?.html || "";
    },
    image: (block)=>{
        const file = block.data?.file || {};
        const caption = block.data?.caption || "";
        const withBorder = block.data?.withBorder || false;
        const withBackground = block.data?.withBackground || false;
        const stretched = block.data?.stretched || false;
        if (!file.url) return "";
        const classes = [
            "editorjs-image",
            withBorder && "editorjs-image-border",
            withBackground && "editorjs-image-background",
            stretched && "editorjs-image-stretched"
        ].filter(Boolean).join(" ");
        return `
			<figure class="${classes}">
				<img src="${file.url}" alt="${caption}" />
				${caption ? `<figcaption>${caption}</figcaption>` : ""}
			</figure>
		`;
    },
    embed: (block)=>{
        const { embed, width, height, caption } = block.data || {};
        if (!embed) return "";
        // Check if this is a YouTube embed
        const youtubeMatch = embed.match(/(?:youtube\.com\/embed\/|youtu\.be\/)([a-zA-Z0-9_-]+)/);
        if (youtubeMatch && youtubeMatch[1]) {
            // Generate a special marker for YouTube embeds that will be hydrated client-side
            const videoId = youtubeMatch[1];
            return `
				<div
					class="youtube-embed-placeholder"
					data-video-id="${videoId}"
					data-width="${width || '100%'}"
					data-height="${height || '450px'}"
					data-caption="${caption || ''}"
				></div>
			`;
        }
        // For non-YouTube embeds, render normally
        return `
			<div class="editorjs-embed">
				<div class="editorjs-embed-content" style="${width ? `width: ${width}px;` : ""} ${height ? `height: ${height}px;` : ""}">
					${embed}
				</div>
				${caption ? `<div class="editorjs-embed-caption">${caption}</div>` : ""}
			</div>
		`;
    }
};
/**
 * Format file size to human-readable format
 */ function formatFileSize(bytes) {
    if (bytes === 0) return "0 Bytes";
    const k = 1024;
    const sizes = [
        "Bytes",
        "KB",
        "MB",
        "GB"
    ];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round(bytes / Math.pow(k, i) * 100) / 100 + " " + sizes[i];
}
const createEditorJsParser = ()=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$editorjs$2d$html$40$3$2e$4$2e$3$2f$node_modules$2f$editorjs$2d$html$2f$build$2f$edjsHTML$2e$node$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"])(customParsers);
};
const parseEditorJsToHTML = (data)=>{
    try {
        const parser = createEditorJsParser();
        const jsonData = typeof data === "string" ? JSON.parse(data) : data;
        return parser.parse(jsonData);
    } catch (error) {
        console.error("Failed to parse Editor.js content:", error);
        return [];
    }
};
}),
"[project]/src/ui/components/EditorJsContent.tsx [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "EditorJsContent",
    ()=>EditorJsContent
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$0$2d$canary$2e$8_$40$babel$2b$core$40$7$2e$24$2e$9_$40$playwright$2b$test$40$1$2e$50$2e$1_react$2d$dom$40$19$2e$3$2e$0$2d$canary$2d$1873a_2mtuduerrj4u77p2gsx7joqpla$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.0.0-canary.8_@babel+core@7.24.9_@playwright+test@1.50.1_react-dom@19.3.0-canary-1873a_2mtuduerrj4u77p2gsx7joqpla/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const EditorJsContent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$0$2d$canary$2e$8_$40$babel$2b$core$40$7$2e$24$2e$9_$40$playwright$2b$test$40$1$2e$50$2e$1_react$2d$dom$40$19$2e$3$2e$0$2d$canary$2d$1873a_2mtuduerrj4u77p2gsx7joqpla$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call EditorJsContent() from the server but EditorJsContent is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/src/ui/components/EditorJsContent.tsx <module evaluation>", "EditorJsContent");
}),
"[project]/src/ui/components/EditorJsContent.tsx [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "EditorJsContent",
    ()=>EditorJsContent
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$0$2d$canary$2e$8_$40$babel$2b$core$40$7$2e$24$2e$9_$40$playwright$2b$test$40$1$2e$50$2e$1_react$2d$dom$40$19$2e$3$2e$0$2d$canary$2d$1873a_2mtuduerrj4u77p2gsx7joqpla$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.0.0-canary.8_@babel+core@7.24.9_@playwright+test@1.50.1_react-dom@19.3.0-canary-1873a_2mtuduerrj4u77p2gsx7joqpla/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const EditorJsContent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$0$2d$canary$2e$8_$40$babel$2b$core$40$7$2e$24$2e$9_$40$playwright$2b$test$40$1$2e$50$2e$1_react$2d$dom$40$19$2e$3$2e$0$2d$canary$2d$1873a_2mtuduerrj4u77p2gsx7joqpla$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call EditorJsContent() from the server but EditorJsContent is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/src/ui/components/EditorJsContent.tsx", "EditorJsContent");
}),
"[project]/src/ui/components/EditorJsContent.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$ui$2f$components$2f$EditorJsContent$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/src/ui/components/EditorJsContent.tsx [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$ui$2f$components$2f$EditorJsContent$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/src/ui/components/EditorJsContent.tsx [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$ui$2f$components$2f$EditorJsContent$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/src/app/(main)/pages/[slug]/page.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Page,
    "generateMetadata",
    ()=>generateMetadata
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$0$2d$canary$2e$8_$40$babel$2b$core$40$7$2e$24$2e$9_$40$playwright$2b$test$40$1$2e$50$2e$1_react$2d$dom$40$19$2e$3$2e$0$2d$canary$2d$1873a_2mtuduerrj4u77p2gsx7joqpla$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.0.0-canary.8_@babel+core@7.24.9_@playwright+test@1.50.1_react-dom@19.3.0-canary-1873a_2mtuduerrj4u77p2gsx7joqpla/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$0$2d$canary$2e$8_$40$babel$2b$core$40$7$2e$24$2e$9_$40$playwright$2b$test$40$1$2e$50$2e$1_react$2d$dom$40$19$2e$3$2e$0$2d$canary$2d$1873a_2mtuduerrj4u77p2gsx7joqpla$2f$node_modules$2f$next$2f$dist$2f$api$2f$navigation$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.0.0-canary.8_@babel+core@7.24.9_@playwright+test@1.50.1_react-dom@19.3.0-canary-1873a_2mtuduerrj4u77p2gsx7joqpla/node_modules/next/dist/api/navigation.react-server.js [app-rsc] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$0$2d$canary$2e$8_$40$babel$2b$core$40$7$2e$24$2e$9_$40$playwright$2b$test$40$1$2e$50$2e$1_react$2d$dom$40$19$2e$3$2e$0$2d$canary$2d$1873a_2mtuduerrj4u77p2gsx7joqpla$2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$navigation$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.0.0-canary.8_@babel+core@7.24.9_@playwright+test@1.50.1_react-dom@19.3.0-canary-1873a_2mtuduerrj4u77p2gsx7joqpla/node_modules/next/dist/client/components/navigation.react-server.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$gql$2f$graphql$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/gql/graphql.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$graphql$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/graphql.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$editorjs$2f$parser$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/editorjs/parser.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$ui$2f$components$2f$EditorJsContent$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/ui/components/EditorJsContent.tsx [app-rsc] (ecmascript)");
;
;
;
;
;
;
const generateMetadata = async (props)=>{
    const params = await props.params;
    const { page } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$graphql$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["executeGraphQL"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$gql$2f$graphql$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["PageGetBySlugDocument"], {
        variables: {
            slug: params.slug
        },
        revalidate: 60
    });
    return {
        title: `${page?.seoTitle || page?.title || "Page"} · Saleor Storefront example`,
        description: page?.seoDescription || page?.seoTitle || page?.title
    };
};
async function Page(props) {
    const params = await props.params;
    const { page } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$graphql$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["executeGraphQL"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$gql$2f$graphql$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["PageGetBySlugDocument"], {
        variables: {
            slug: params.slug
        },
        revalidate: 60
    });
    if (!page) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$0$2d$canary$2e$8_$40$babel$2b$core$40$7$2e$24$2e$9_$40$playwright$2b$test$40$1$2e$50$2e$1_react$2d$dom$40$19$2e$3$2e$0$2d$canary$2d$1873a_2mtuduerrj4u77p2gsx7joqpla$2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$navigation$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["notFound"])();
    }
    const { title, content } = page;
    const contentHtml = content ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$editorjs$2f$parser$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["parseEditorJsToHTML"])(content) : null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$0$2d$canary$2e$8_$40$babel$2b$core$40$7$2e$24$2e$9_$40$playwright$2b$test$40$1$2e$50$2e$1_react$2d$dom$40$19$2e$3$2e$0$2d$canary$2d$1873a_2mtuduerrj4u77p2gsx7joqpla$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "mx-auto max-w-7xl p-8 pb-16",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$0$2d$canary$2e$8_$40$babel$2b$core$40$7$2e$24$2e$9_$40$playwright$2b$test$40$1$2e$50$2e$1_react$2d$dom$40$19$2e$3$2e$0$2d$canary$2d$1873a_2mtuduerrj4u77p2gsx7joqpla$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                className: "text-3xl font-semibold",
                children: title
            }, void 0, false, {
                fileName: "[project]/src/app/(main)/pages/[slug]/page.tsx",
                lineNumber: 38,
                columnNumber: 4
            }, this),
            contentHtml && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$0$2d$canary$2e$8_$40$babel$2b$core$40$7$2e$24$2e$9_$40$playwright$2b$test$40$1$2e$50$2e$1_react$2d$dom$40$19$2e$3$2e$0$2d$canary$2d$1873a_2mtuduerrj4u77p2gsx7joqpla$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "prose",
                children: contentHtml.map((content, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$0$2d$canary$2e$8_$40$babel$2b$core$40$7$2e$24$2e$9_$40$playwright$2b$test$40$1$2e$50$2e$1_react$2d$dom$40$19$2e$3$2e$0$2d$canary$2d$1873a_2mtuduerrj4u77p2gsx7joqpla$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$ui$2f$components$2f$EditorJsContent$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["EditorJsContent"], {
                        html: content
                    }, index, false, {
                        fileName: "[project]/src/app/(main)/pages/[slug]/page.tsx",
                        lineNumber: 42,
                        columnNumber: 7
                    }, this))
            }, void 0, false, {
                fileName: "[project]/src/app/(main)/pages/[slug]/page.tsx",
                lineNumber: 40,
                columnNumber: 5
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/(main)/pages/[slug]/page.tsx",
        lineNumber: 37,
        columnNumber: 3
    }, this);
}
}),
"[project]/src/app/(main)/pages/[slug]/page.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/(main)/pages/[slug]/page.tsx [app-rsc] (ecmascript)"));
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__7e5ce53f._.js.map