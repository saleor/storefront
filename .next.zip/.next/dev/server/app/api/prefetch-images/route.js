var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/prefetch-images/route.js")
R.c("server/chunks/[root-of-the-server]__be0b4f08._.js")
R.c("server/chunks/node_modules__pnpm_faf6954c._.js")
R.c("server/chunks/_next-internal_server_app_api_prefetch-images_route_actions_caa1cf47.js")
R.m("[project]/node_modules/.pnpm/next@16.0.0-canary.8_@babel+core@7.24.9_@playwright+test@1.50.1_react-dom@19.3.0-canary-1873a_2mtuduerrj4u77p2gsx7joqpla/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/prefetch-images/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/.pnpm/next@16.0.0-canary.8_@babel+core@7.24.9_@playwright+test@1.50.1_react-dom@19.3.0-canary-1873a_2mtuduerrj4u77p2gsx7joqpla/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/prefetch-images/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
