(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["chunks/[root-of-the-server]__8978dbac._.js",
"[externals]/node:buffer [external] (node:buffer, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:buffer", () => require("node:buffer"));

module.exports = mod;
}),
"[externals]/node:async_hooks [external] (node:async_hooks, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:async_hooks", () => require("node:async_hooks"));

module.exports = mod;
}),
"[project]/src/middleware.ts [middleware-edge] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "config",
    ()=>config,
    "middleware",
    ()=>middleware
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$0$2d$canary$2e$8_$40$babel$2b$core$40$7$2e$24$2e$9_$40$playwright$2b$test$40$1$2e$50$2e$1_react$2d$dom$40$19$2e$3$2e$0$2d$canary$2d$1873a_2mtuduerrj4u77p2gsx7joqpla$2f$node_modules$2f$next$2f$dist$2f$esm$2f$api$2f$server$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.0.0-canary.8_@babel+core@7.24.9_@playwright+test@1.50.1_react-dom@19.3.0-canary-1873a_2mtuduerrj4u77p2gsx7joqpla/node_modules/next/dist/esm/api/server.js [middleware-edge] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$0$2d$canary$2e$8_$40$babel$2b$core$40$7$2e$24$2e$9_$40$playwright$2b$test$40$1$2e$50$2e$1_react$2d$dom$40$19$2e$3$2e$0$2d$canary$2d$1873a_2mtuduerrj4u77p2gsx7joqpla$2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$web$2f$exports$2f$index$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.0.0-canary.8_@babel+core@7.24.9_@playwright+test@1.50.1_react-dom@19.3.0-canary-1873a_2mtuduerrj4u77p2gsx7joqpla/node_modules/next/dist/esm/server/web/exports/index.js [middleware-edge] (ecmascript)");
;
function middleware(request) {
    const response = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$0$2d$canary$2e$8_$40$babel$2b$core$40$7$2e$24$2e$9_$40$playwright$2b$test$40$1$2e$50$2e$1_react$2d$dom$40$19$2e$3$2e$0$2d$canary$2d$1873a_2mtuduerrj4u77p2gsx7joqpla$2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$web$2f$exports$2f$index$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["NextResponse"].next();
    // Enable back/forward cache by avoiding cache-control: no-store
    // For product pages and listings, use cache with revalidation
    const pathname = request.nextUrl.pathname;
    if (pathname.includes("/products") || pathname.includes("/categories") || pathname.includes("/collections")) {
        // Allow caching with revalidation for better bfcache support
        response.headers.set("Cache-Control", "public, max-age=0, must-revalidate, stale-while-revalidate=59");
    }
    return response;
}
const config = {
    matcher: [
        /*
		 * Match all request paths except:
		 * - _next/static (static files)
		 * - _next/image (image optimization files)
		 * - favicon.ico (favicon file)
		 * - public folder files
		 */ "/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp|ico|ttf|woff|woff2)$).*)"
    ]
};
}),
]);

//# sourceMappingURL=%5Broot-of-the-server%5D__8978dbac._.js.map