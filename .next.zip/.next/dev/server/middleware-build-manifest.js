globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/7c561_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_0f4ca5e4._.js",
    "static/chunks/4ae09_dist_compiled_react-dom-experimental_cjs_react-dom-client_development_79bed2c4.js",
    "static/chunks/7c561_next_dist_compiled_react-dom-experimental_cjs_react-dom_development_6317fb80.js",
    "static/chunks/7c561_next_dist_compiled_react-dom-experimental_b56a746c._.js",
    "static/chunks/7c561_next_dist_compiled_react-server-dom-turbopack-experimental_eb90fe18._.js",
    "static/chunks/7c561_next_dist_compiled_next-devtools_index_d749a5f3.js",
    "static/chunks/7c561_next_dist_compiled_92eb2ed1._.js",
    "static/chunks/7c561_next_dist_client_4719157d._.js",
    "static/chunks/7c561_next_dist_7afff0a1._.js",
    "static/chunks/69652_@swc_helpers_cjs_679851cc._.js",
    "static/chunks/_a0ff3932._.js",
    "static/chunks/turbopack-_ab1fcff7._.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];