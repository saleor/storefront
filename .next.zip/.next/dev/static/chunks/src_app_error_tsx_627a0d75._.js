(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/app/error.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Error
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$0$2d$canary$2e$8_$40$babel$2b$core$40$7$2e$24$2e$9_$40$playwright$2b$test$40$1$2e$50$2e$1_react$2d$dom$40$19$2e$3$2e$0$2d$canary$2d$1873a_2mtuduerrj4u77p2gsx7joqpla$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$experimental$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.0.0-canary.8_@babel+core@7.24.9_@playwright+test@1.50.1_react-dom@19.3.0-canary-1873a_2mtuduerrj4u77p2gsx7joqpla/node_modules/next/dist/compiled/react-experimental/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$0$2d$canary$2e$8_$40$babel$2b$core$40$7$2e$24$2e$9_$40$playwright$2b$test$40$1$2e$50$2e$1_react$2d$dom$40$19$2e$3$2e$0$2d$canary$2d$1873a_2mtuduerrj4u77p2gsx7joqpla$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$experimental$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.0.0-canary.8_@babel+core@7.24.9_@playwright+test@1.50.1_react-dom@19.3.0-canary-1873a_2mtuduerrj4u77p2gsx7joqpla/node_modules/next/dist/compiled/react-experimental/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
function Error({ error, reset }) {
    _s();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$0$2d$canary$2e$8_$40$babel$2b$core$40$7$2e$24$2e$9_$40$playwright$2b$test$40$1$2e$50$2e$1_react$2d$dom$40$19$2e$3$2e$0$2d$canary$2d$1873a_2mtuduerrj4u77p2gsx7joqpla$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$experimental$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Error.useEffect": ()=>{
            console.error(error);
        }
    }["Error.useEffect"], [
        error
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$0$2d$canary$2e$8_$40$babel$2b$core$40$7$2e$24$2e$9_$40$playwright$2b$test$40$1$2e$50$2e$1_react$2d$dom$40$19$2e$3$2e$0$2d$canary$2d$1873a_2mtuduerrj4u77p2gsx7joqpla$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$experimental$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "bg-white",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$0$2d$canary$2e$8_$40$babel$2b$core$40$7$2e$24$2e$9_$40$playwright$2b$test$40$1$2e$50$2e$1_react$2d$dom$40$19$2e$3$2e$0$2d$canary$2d$1873a_2mtuduerrj4u77p2gsx7joqpla$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$experimental$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "mx-auto max-w-7xl px-6 py-12",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$0$2d$canary$2e$8_$40$babel$2b$core$40$7$2e$24$2e$9_$40$playwright$2b$test$40$1$2e$50$2e$1_react$2d$dom$40$19$2e$3$2e$0$2d$canary$2d$1873a_2mtuduerrj4u77p2gsx7joqpla$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$experimental$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                    className: "text-2xl font-bold leading-10 tracking-tight text-neutral-800",
                    children: "Something went wrong"
                }, void 0, false, {
                    fileName: "[project]/src/app/error.tsx",
                    lineNumber: 13,
                    columnNumber: 5
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$0$2d$canary$2e$8_$40$babel$2b$core$40$7$2e$24$2e$9_$40$playwright$2b$test$40$1$2e$50$2e$1_react$2d$dom$40$19$2e$3$2e$0$2d$canary$2d$1873a_2mtuduerrj4u77p2gsx7joqpla$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$experimental$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "mt-6 max-w-2xl text-base leading-7 text-neutral-600",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$0$2d$canary$2e$8_$40$babel$2b$core$40$7$2e$24$2e$9_$40$playwright$2b$test$40$1$2e$50$2e$1_react$2d$dom$40$19$2e$3$2e$0$2d$canary$2d$1873a_2mtuduerrj4u77p2gsx7joqpla$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$experimental$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("code", {
                        children: error.message
                    }, void 0, false, {
                        fileName: "[project]/src/app/error.tsx",
                        lineNumber: 17,
                        columnNumber: 6
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/app/error.tsx",
                    lineNumber: 16,
                    columnNumber: 5
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$0$2d$canary$2e$8_$40$babel$2b$core$40$7$2e$24$2e$9_$40$playwright$2b$test$40$1$2e$50$2e$1_react$2d$dom$40$19$2e$3$2e$0$2d$canary$2d$1873a_2mtuduerrj4u77p2gsx7joqpla$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$experimental$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    className: "mt-8 h-10 rounded-md bg-red-500 px-6 font-semibold text-white",
                    onClick: ()=>reset(),
                    children: "Try again"
                }, void 0, false, {
                    fileName: "[project]/src/app/error.tsx",
                    lineNumber: 19,
                    columnNumber: 5
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/error.tsx",
            lineNumber: 12,
            columnNumber: 4
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/error.tsx",
        lineNumber: 11,
        columnNumber: 3
    }, this);
}
_s(Error, "OD7bBpZva5O2jO+Puf00hKivP7c=");
_c = Error;
var _c;
__turbopack_context__.k.register(_c, "Error");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_app_error_tsx_627a0d75._.js.map