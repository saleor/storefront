(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules__pnpm_3a684c7b._.js",
  "static/chunks/src_69c94ee3._.js"
],
    source: "dynamic"
});
