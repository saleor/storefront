(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/ui/components/YouTubeEmbed.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "YouTubeEmbed",
    ()=>YouTubeEmbed
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$0$2d$canary$2e$8_$40$babel$2b$core$40$7$2e$24$2e$9_$40$playwright$2b$test$40$1$2e$50$2e$1_react$2d$dom$40$19$2e$3$2e$0$2d$canary$2d$1873a_2mtuduerrj4u77p2gsx7joqpla$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$experimental$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.0.0-canary.8_@babel+core@7.24.9_@playwright+test@1.50.1_react-dom@19.3.0-canary-1873a_2mtuduerrj4u77p2gsx7joqpla/node_modules/next/dist/compiled/react-experimental/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useCookieConsent$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/hooks/useCookieConsent.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$CookieConsentContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/contexts/CookieConsentContext.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
function YouTubeEmbed({ videoId, width = "100%", height = "450px", caption }) {
    _s();
    const { hasConsent, openSettings } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$CookieConsentContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCookieConsent"])();
    const youtubeAllowed = hasConsent("youtube");
    if (youtubeAllowed) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$0$2d$canary$2e$8_$40$babel$2b$core$40$7$2e$24$2e$9_$40$playwright$2b$test$40$1$2e$50$2e$1_react$2d$dom$40$19$2e$3$2e$0$2d$canary$2d$1873a_2mtuduerrj4u77p2gsx7joqpla$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$experimental$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "editorjs-embed editorjs-youtube",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$0$2d$canary$2e$8_$40$babel$2b$core$40$7$2e$24$2e$9_$40$playwright$2b$test$40$1$2e$50$2e$1_react$2d$dom$40$19$2e$3$2e$0$2d$canary$2d$1873a_2mtuduerrj4u77p2gsx7joqpla$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$experimental$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "relative",
                    style: {
                        width,
                        paddingBottom: "56.25%"
                    },
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$0$2d$canary$2e$8_$40$babel$2b$core$40$7$2e$24$2e$9_$40$playwright$2b$test$40$1$2e$50$2e$1_react$2d$dom$40$19$2e$3$2e$0$2d$canary$2d$1873a_2mtuduerrj4u77p2gsx7joqpla$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$experimental$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("iframe", {
                        src: `https://www.youtube-nocookie.com/embed/${videoId}`,
                        title: caption || "YouTube video",
                        allow: "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture",
                        allowFullScreen: true,
                        className: "absolute top-0 left-0 w-full h-full rounded-lg",
                        style: {
                            border: "none"
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/ui/components/YouTubeEmbed.tsx",
                        lineNumber: 24,
                        columnNumber: 6
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/ui/components/YouTubeEmbed.tsx",
                    lineNumber: 23,
                    columnNumber: 5
                }, this),
                caption && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$0$2d$canary$2e$8_$40$babel$2b$core$40$7$2e$24$2e$9_$40$playwright$2b$test$40$1$2e$50$2e$1_react$2d$dom$40$19$2e$3$2e$0$2d$canary$2d$1873a_2mtuduerrj4u77p2gsx7joqpla$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$experimental$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "editorjs-embed-caption mt-2 text-center text-sm text-gray-400",
                    children: caption
                }, void 0, false, {
                    fileName: "[project]/src/ui/components/YouTubeEmbed.tsx",
                    lineNumber: 33,
                    columnNumber: 17
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/ui/components/YouTubeEmbed.tsx",
            lineNumber: 22,
            columnNumber: 4
        }, this);
    }
    // Show placeholder when consent is not given
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$0$2d$canary$2e$8_$40$babel$2b$core$40$7$2e$24$2e$9_$40$playwright$2b$test$40$1$2e$50$2e$1_react$2d$dom$40$19$2e$3$2e$0$2d$canary$2d$1873a_2mtuduerrj4u77p2gsx7joqpla$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$experimental$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "editorjs-embed editorjs-youtube-blocked",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$0$2d$canary$2e$8_$40$babel$2b$core$40$7$2e$24$2e$9_$40$playwright$2b$test$40$1$2e$50$2e$1_react$2d$dom$40$19$2e$3$2e$0$2d$canary$2d$1873a_2mtuduerrj4u77p2gsx7joqpla$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$experimental$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative flex flex-col items-center justify-center bg-base-900 rounded-lg border-2 border-base-700 p-12",
                style: {
                    width,
                    height
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$0$2d$canary$2e$8_$40$babel$2b$core$40$7$2e$24$2e$9_$40$playwright$2b$test$40$1$2e$50$2e$1_react$2d$dom$40$19$2e$3$2e$0$2d$canary$2d$1873a_2mtuduerrj4u77p2gsx7joqpla$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$experimental$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                        className: "w-16 h-16 text-base-600 mb-4",
                        fill: "currentColor",
                        viewBox: "0 0 24 24",
                        xmlns: "http://www.w3.org/2000/svg",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$0$2d$canary$2e$8_$40$babel$2b$core$40$7$2e$24$2e$9_$40$playwright$2b$test$40$1$2e$50$2e$1_react$2d$dom$40$19$2e$3$2e$0$2d$canary$2d$1873a_2mtuduerrj4u77p2gsx7joqpla$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$experimental$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"
                        }, void 0, false, {
                            fileName: "[project]/src/ui/components/YouTubeEmbed.tsx",
                            lineNumber: 51,
                            columnNumber: 6
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/ui/components/YouTubeEmbed.tsx",
                        lineNumber: 45,
                        columnNumber: 5
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$0$2d$canary$2e$8_$40$babel$2b$core$40$7$2e$24$2e$9_$40$playwright$2b$test$40$1$2e$50$2e$1_react$2d$dom$40$19$2e$3$2e$0$2d$canary$2d$1873a_2mtuduerrj4u77p2gsx7joqpla$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$experimental$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-base-200 font-medium mb-2",
                        children: "YouTube video blocked"
                    }, void 0, false, {
                        fileName: "[project]/src/ui/components/YouTubeEmbed.tsx",
                        lineNumber: 53,
                        columnNumber: 5
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$0$2d$canary$2e$8_$40$babel$2b$core$40$7$2e$24$2e$9_$40$playwright$2b$test$40$1$2e$50$2e$1_react$2d$dom$40$19$2e$3$2e$0$2d$canary$2d$1873a_2mtuduerrj4u77p2gsx7joqpla$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$experimental$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-base-400 text-sm mb-4 px-4 text-center",
                        children: "This content requires your consent to view YouTube videos."
                    }, void 0, false, {
                        fileName: "[project]/src/ui/components/YouTubeEmbed.tsx",
                        lineNumber: 54,
                        columnNumber: 5
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$0$2d$canary$2e$8_$40$babel$2b$core$40$7$2e$24$2e$9_$40$playwright$2b$test$40$1$2e$50$2e$1_react$2d$dom$40$19$2e$3$2e$0$2d$canary$2d$1873a_2mtuduerrj4u77p2gsx7joqpla$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$experimental$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: openSettings,
                        className: "px-4 py-2 bg-accent-700 hover:bg-accent-600 text-white rounded-lg transition-colors text-sm font-medium",
                        children: "Manage Cookie Settings"
                    }, void 0, false, {
                        fileName: "[project]/src/ui/components/YouTubeEmbed.tsx",
                        lineNumber: 57,
                        columnNumber: 5
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/ui/components/YouTubeEmbed.tsx",
                lineNumber: 41,
                columnNumber: 4
            }, this),
            caption && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$0$2d$canary$2e$8_$40$babel$2b$core$40$7$2e$24$2e$9_$40$playwright$2b$test$40$1$2e$50$2e$1_react$2d$dom$40$19$2e$3$2e$0$2d$canary$2d$1873a_2mtuduerrj4u77p2gsx7joqpla$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$experimental$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "editorjs-embed-caption mt-2 text-center text-sm text-base-400",
                children: caption
            }, void 0, false, {
                fileName: "[project]/src/ui/components/YouTubeEmbed.tsx",
                lineNumber: 64,
                columnNumber: 16
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/ui/components/YouTubeEmbed.tsx",
        lineNumber: 40,
        columnNumber: 3
    }, this);
}
_s(YouTubeEmbed, "6flG21Qju4p5MUTgFGXnOeHnqKY=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$CookieConsentContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCookieConsent"]
    ];
});
_c = YouTubeEmbed;
var _c;
__turbopack_context__.k.register(_c, "YouTubeEmbed");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/ui/components/EditorJsContent.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "EditorJsContent",
    ()=>EditorJsContent
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$0$2d$canary$2e$8_$40$babel$2b$core$40$7$2e$24$2e$9_$40$playwright$2b$test$40$1$2e$50$2e$1_react$2d$dom$40$19$2e$3$2e$0$2d$canary$2d$1873a_2mtuduerrj4u77p2gsx7joqpla$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$experimental$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.0.0-canary.8_@babel+core@7.24.9_@playwright+test@1.50.1_react-dom@19.3.0-canary-1873a_2mtuduerrj4u77p2gsx7joqpla/node_modules/next/dist/compiled/react-experimental/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$0$2d$canary$2e$8_$40$babel$2b$core$40$7$2e$24$2e$9_$40$playwright$2b$test$40$1$2e$50$2e$1_react$2d$dom$40$19$2e$3$2e$0$2d$canary$2d$1873a_2mtuduerrj4u77p2gsx7joqpla$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$experimental$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.0.0-canary.8_@babel+core@7.24.9_@playwright+test@1.50.1_react-dom@19.3.0-canary-1873a_2mtuduerrj4u77p2gsx7joqpla/node_modules/next/dist/compiled/react-experimental/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$ui$2f$components$2f$YouTubeEmbed$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/ui/components/YouTubeEmbed.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
/**
 * Parse HTML and extract YouTube placeholders
 */ function parseHtmlWithYouTube(html) {
    // Split HTML by YouTube placeholders
    const youtubeRegex = /<div[^>]*class="youtube-embed-placeholder"[^>]*data-video-id="([^"]+)"(?:[^>]*data-width="([^"]*)")?(?:[^>]*data-height="([^"]*)")?(?:[^>]*data-caption="([^"]*)")?[^>]*><\/div>/g;
    const htmlParts = [];
    const youtubeEmbeds = [];
    let lastIndex = 0;
    let match;
    while((match = youtubeRegex.exec(html)) !== null){
        // Add HTML before this placeholder
        htmlParts.push(html.substring(lastIndex, match.index));
        // Extract YouTube data
        youtubeEmbeds.push({
            videoId: match[1],
            width: match[2] || undefined,
            height: match[3] || undefined,
            caption: match[4] || undefined
        });
        lastIndex = match.index + match[0].length;
    }
    // Add remaining HTML
    htmlParts.push(html.substring(lastIndex));
    return {
        htmlParts,
        youtubeEmbeds
    };
}
function EditorJsContent({ html, className = "" }) {
    _s();
    const { htmlParts, youtubeEmbeds } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$0$2d$canary$2e$8_$40$babel$2b$core$40$7$2e$24$2e$9_$40$playwright$2b$test$40$1$2e$50$2e$1_react$2d$dom$40$19$2e$3$2e$0$2d$canary$2d$1873a_2mtuduerrj4u77p2gsx7joqpla$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$experimental$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "EditorJsContent.useMemo": ()=>parseHtmlWithYouTube(html)
    }["EditorJsContent.useMemo"], [
        html
    ]);
    // If no YouTube embeds, render HTML as-is
    if (youtubeEmbeds.length === 0) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$0$2d$canary$2e$8_$40$babel$2b$core$40$7$2e$24$2e$9_$40$playwright$2b$test$40$1$2e$50$2e$1_react$2d$dom$40$19$2e$3$2e$0$2d$canary$2d$1873a_2mtuduerrj4u77p2gsx7joqpla$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$experimental$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: className,
            dangerouslySetInnerHTML: {
                __html: html
            }
        }, void 0, false, {
            fileName: "[project]/src/ui/components/EditorJsContent.tsx",
            lineNumber: 67,
            columnNumber: 10
        }, this);
    }
    // Render HTML parts with YouTube embeds interleaved
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$0$2d$canary$2e$8_$40$babel$2b$core$40$7$2e$24$2e$9_$40$playwright$2b$test$40$1$2e$50$2e$1_react$2d$dom$40$19$2e$3$2e$0$2d$canary$2d$1873a_2mtuduerrj4u77p2gsx7joqpla$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$experimental$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: className,
        children: htmlParts.map((htmlPart, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$0$2d$canary$2e$8_$40$babel$2b$core$40$7$2e$24$2e$9_$40$playwright$2b$test$40$1$2e$50$2e$1_react$2d$dom$40$19$2e$3$2e$0$2d$canary$2d$1873a_2mtuduerrj4u77p2gsx7joqpla$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$experimental$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$0$2d$canary$2e$8_$40$babel$2b$core$40$7$2e$24$2e$9_$40$playwright$2b$test$40$1$2e$50$2e$1_react$2d$dom$40$19$2e$3$2e$0$2d$canary$2d$1873a_2mtuduerrj4u77p2gsx7joqpla$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$experimental$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        dangerouslySetInnerHTML: {
                            __html: htmlPart
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/ui/components/EditorJsContent.tsx",
                        lineNumber: 75,
                        columnNumber: 6
                    }, this),
                    youtubeEmbeds[index] && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$0$2d$canary$2e$8_$40$babel$2b$core$40$7$2e$24$2e$9_$40$playwright$2b$test$40$1$2e$50$2e$1_react$2d$dom$40$19$2e$3$2e$0$2d$canary$2d$1873a_2mtuduerrj4u77p2gsx7joqpla$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$experimental$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$ui$2f$components$2f$YouTubeEmbed$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["YouTubeEmbed"], {
                        videoId: youtubeEmbeds[index].videoId,
                        width: youtubeEmbeds[index].width,
                        height: youtubeEmbeds[index].height,
                        caption: youtubeEmbeds[index].caption
                    }, void 0, false, {
                        fileName: "[project]/src/ui/components/EditorJsContent.tsx",
                        lineNumber: 77,
                        columnNumber: 7
                    }, this)
                ]
            }, index, true, {
                fileName: "[project]/src/ui/components/EditorJsContent.tsx",
                lineNumber: 74,
                columnNumber: 5
            }, this))
    }, void 0, false, {
        fileName: "[project]/src/ui/components/EditorJsContent.tsx",
        lineNumber: 72,
        columnNumber: 3
    }, this);
}
_s(EditorJsContent, "IYGLoPtaOOJMwkNIj3aNNOL09gE=");
_c = EditorJsContent;
var _c;
__turbopack_context__.k.register(_c, "EditorJsContent");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_ui_components_6eeab27b._.js.map