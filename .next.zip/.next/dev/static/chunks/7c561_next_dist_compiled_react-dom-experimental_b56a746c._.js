(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/node_modules/.pnpm/next@16.0.0-canary.8_@babel+core@7.24.9_@playwright+test@1.50.1_react-dom@19.3.0-canary-1873a_2mtuduerrj4u77p2gsx7joqpla/node_modules/next/dist/compiled/react-dom-experimental/index.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$0$2d$canary$2e$8_$40$babel$2b$core$40$7$2e$24$2e$9_$40$playwright$2b$test$40$1$2e$50$2e$1_react$2d$dom$40$19$2e$3$2e$0$2d$canary$2d$1873a_2mtuduerrj4u77p2gsx7joqpla$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.0.0-canary.8_@babel+core@7.24.9_@playwright+test@1.50.1_react-dom@19.3.0-canary-1873a_2mtuduerrj4u77p2gsx7joqpla/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
'use strict';
function checkDCE() {
    /* global __REACT_DEVTOOLS_GLOBAL_HOOK__ */ if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ === 'undefined' || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE !== 'function') {
        return;
    }
    if ("TURBOPACK compile-time truthy", 1) {
        // This branch is unreachable because this function is only called
        // in production, but the condition is true only in development.
        // Therefore if the branch is still here, dead code elimination wasn't
        // properly applied.
        // Don't change the message. React DevTools relies on it. Also make sure
        // this message doesn't occur elsewhere in this function, or it will cause
        // a false positive.
        throw new Error('^_^');
    }
    try {
        // Verify that the code above has been dead code eliminated (DCE'd).
        __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(checkDCE);
    } catch (err) {
        // DevTools shouldn't crash React, no matter what.
        // We should still report in case we break this code.
        console.error(err);
    }
}
if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
;
else {
    module.exports = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.0.0-canary.8_@babel+core@7.24.9_@playwright+test@1.50.1_react-dom@19.3.0-canary-1873a_2mtuduerrj4u77p2gsx7joqpla/node_modules/next/dist/compiled/react-dom-experimental/cjs/react-dom.development.js [app-client] (ecmascript)");
}
}),
"[project]/node_modules/.pnpm/next@16.0.0-canary.8_@babel+core@7.24.9_@playwright+test@1.50.1_react-dom@19.3.0-canary-1873a_2mtuduerrj4u77p2gsx7joqpla/node_modules/next/dist/compiled/react-dom-experimental/client.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$0$2d$canary$2e$8_$40$babel$2b$core$40$7$2e$24$2e$9_$40$playwright$2b$test$40$1$2e$50$2e$1_react$2d$dom$40$19$2e$3$2e$0$2d$canary$2d$1873a_2mtuduerrj4u77p2gsx7joqpla$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.0.0-canary.8_@babel+core@7.24.9_@playwright+test@1.50.1_react-dom@19.3.0-canary-1873a_2mtuduerrj4u77p2gsx7joqpla/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
'use strict';
function checkDCE() {
    /* global __REACT_DEVTOOLS_GLOBAL_HOOK__ */ if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ === 'undefined' || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE !== 'function') {
        return;
    }
    if ("TURBOPACK compile-time truthy", 1) {
        // This branch is unreachable because this function is only called
        // in production, but the condition is true only in development.
        // Therefore if the branch is still here, dead code elimination wasn't
        // properly applied.
        // Don't change the message. React DevTools relies on it. Also make sure
        // this message doesn't occur elsewhere in this function, or it will cause
        // a false positive.
        throw new Error('^_^');
    }
    try {
        // Verify that the code above has been dead code eliminated (DCE'd).
        __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(checkDCE);
    } catch (err) {
        // DevTools shouldn't crash React, no matter what.
        // We should still report in case we break this code.
        console.error(err);
    }
}
if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
;
else {
    module.exports = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.0.0-canary.8_@babel+core@7.24.9_@playwright+test@1.50.1_react-dom@19.3.0-canary-1873a_2mtuduerrj4u77p2gsx7joqpla/node_modules/next/dist/compiled/react-dom-experimental/cjs/react-dom-client.development.js [app-client] (ecmascript)");
}
}),
]);

//# sourceMappingURL=7c561_next_dist_compiled_react-dom-experimental_b56a746c._.js.map